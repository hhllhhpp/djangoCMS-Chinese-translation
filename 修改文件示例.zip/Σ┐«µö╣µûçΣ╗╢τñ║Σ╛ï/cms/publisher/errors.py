# -*- coding: utf-8 -*-
class PublisherCantPublish(Exception):
    """Publisher can not publish instance, because there is something wrong"""
