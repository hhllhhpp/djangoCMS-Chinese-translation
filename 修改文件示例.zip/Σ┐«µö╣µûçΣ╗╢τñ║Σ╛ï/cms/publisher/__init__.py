# -*- coding: utf-8 -*-
from .manager import PublisherManager  # nopyflakes

__all__ = ('PublisherManager', 'VERSION')

VERSION = (0, 4, 'sintab')
